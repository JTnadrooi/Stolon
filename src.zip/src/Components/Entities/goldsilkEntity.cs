﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using AsitLib;
using static Stolon.StolonGame;

using Math = System.Math;
using System.Diagnostics;
using Newtonsoft.Json.Linq;
using System.Reflection.Metadata.Ecma335;
using Microsoft.Xna.Framework.Input;
using System.Xml.Linq;
using Microsoft.Xna.Framework;

#nullable enable

namespace Stolon
{
    public class GoldsilkEntity : SLEntity
    {
        public override SLComputer Computer => computer;
        public override Texture2D Splash => Instance.Textures.GetReference("textures\\splash\\goldsilk"); // unrelevant in first ver
        public override string? Description => "This shoulden't be readable in the current verion.";

        private GoldsilkCom computer;

        public GoldsilkEntity() : base("goldsilk", "Opponent", "O")
        {
            computer = new GoldsilkCom(this);
        }

        public override DialogueInfo GetReaction(PrimitiveReactOption reactOption)
        {
            return new DialogueInfo(this, "Lets goooo");
        }
    }
    public class GoldsilkCom : SLComputer
    {

        private Player player;
        private int playerId;

        public GoldsilkCom(GoldsilkEntity source) : base(source)
        {
            player = null!;
        }

        public override void DoMove(Board board)
        {
            //BoardState.Alter(ref board.State, Search(board.State, 2), true);
        }
        //public static Move Search(BoardState state, UniqueMoveBoardMap map)
        //{
        //    Move bestMove = Move.Invalid;
        //    Instance.DebugStream.WriteLine("\t[s]initializing parallel alpha-beta algorithm..");
        //    List<Move> moves = map.GetAllMoves(state);
        //    try
        //    {
        //        Parallel.For(0, moves.Count, i =>
        //        {
        //            BoardState child = state.DeepCopy();
        //            Point sim = child.Alter(moves[i], true);

        //            Console.WriteLine(-Negamax(child, sim, map, 4, -100, 100, -1) + " move: " + moves[i]);
        //        });
        //        //for (int i = 0; i < moves.Count; i++)
        //        //{

        //        //    BoardState child = state.DeepCopy();
        //        //    Point sim = child.Alter(moves[i], true);
        //        //    Console.WriteLine(-Negamax(child, sim, map, 3, -100, 100, -1) + " move: " + moves[i]);
        //        //}
        //    }
        //    catch { }
        //    Instance.DebugStream.Succes(1);
        //    return bestMove;
        //}

        public static Move Search(BoardState state, UniqueMoveBoardMap map, int depth = 3)
        {
            Move bestMove = Move.Invalid;
            Instance.DebugStream.WriteLine("\t[s]initializing parallel alpha-beta algorithm..");
            Dictionary<int, TTEntry> tt = new Dictionary<int, TTEntry>();
            List<Move> moves = map.GetAllMoves(state);
            int color = state.CurrentPlayerID == 1 ? 1 : -1;
            Console.WriteLine(color);
            Console.WriteLine(moves.ToJoinedString(", "));
            Console.WriteLine(state.Tiles[7, 4].GetOccupiedByPlayerID());
            Console.WriteLine(state.Tiles[7, 4].Attributes.ToJoinedString(", "));
            //color = -1;
            //try
            int bestScore = int.MinValue;
            {
                //Parallel.For(0, moves.Count, i =>
                //{
                //    BoardState child = state.DeepCopy();
                //    Point sim = child.Alter(moves[i], true);


                //    int score = -Negamax(child, sim, map, tt, depth, -100, 100, color);
                //    if (score >= bestScore)
                //    {
                //        bestScore = score;
                //        bestMove = moves[i];
                //    }
                //});
                for (int i = 0; i < moves.Count; i++)
                {
                    BoardState child = state.DeepCopy();
                    Point sim = child.Alter(moves[i], true);

                    int score = -Negamax(child, sim, map, tt, depth, -100, 100, color);
                    if (score >= bestScore)
                    {
                        bestScore = score;
                        bestMove = moves[i];
                    }


                    //Point sim = state.Alter(moves[i], true);
                    //Console.WriteLine(-Negamax(state, sim, map, tt, 4, -100, 100, -1) + " move: " + moves[i]);
                    //state.Undo();
                }
            }
            //catch { }
            Instance.DebugStream.WriteLine("\t\tBest move: " + bestMove + " with score: " + bestScore);


            Instance.DebugStream.Succes(1);
            return bestMove;
        }

        public static int Evaluate(BoardState state, int playerId, int? searchRes = null)
        {
            int score = 0;
            int searchAny = searchRes ?? state.SearchAny();

            //if (searchAny == playerId) return 100;
            if (searchAny != -1) return -100;
            return score;
        }
        public struct MinMaxResult
        {
            public int Score { get; }
            public Move Move { get; }
            public MinMaxResult(int score, Move move)
            {
                Score = score;
                Move = move;
            }

            public MinMaxResult InvertScore() => new MinMaxResult(-Score, Move);
            public override string ToString() => "{score: " + Score + ", move:" + Move + "}";
            public static MinMaxResult operator -(MinMaxResult result) => result.InvertScore();
        }
        public static int count = 0;
        //public static int Negamax(BoardState node, Point sim, UniqueMoveBoardMap map, int depth, int alpha, int beta, int color)
        //{
        //    count++;
        //    //if (node.SearchFrom(sim, null, true) != (node.SearchAny() != -1))
        //    //{
        //    //    Console.WriteLine();
        //    //    Console.WriteLine(sim + " sim");
        //    //    Console.WriteLine(node.SearchFrom(sim, null, true) + " sf");
        //    //    Console.WriteLine((node.SearchAny() != -1) + " sa");
        //    //    Console.WriteLine();
        //    //    SLEnvironment.Instance.Scene.Board.State = node;
        //    //    throw new Exception();
        //    //}
        //    if (node.SearchFrom(sim, null, true)) return -100;
        //    if (depth == 0) return 0;


        //    //if (node.SearchAny() != -1) return -100;
        //    //if (depth == 0) return 0;


        //    List<Move> moves = map.GetAllMoves(node);
        //    int value = -100;
        //    for (int i = 0; i < moves.Count; i++)
        //    {
        //        sim = node.Alter(moves[i], true);
        //        value = Math.Max(value, -Negamax(node, sim, map, depth - 1, -beta, -alpha, -color));
        //        node.Undo();

        //        alpha = Math.Max(alpha, value);
        //        if (alpha >= beta) break;
        //    }
        //    return value;
        //}


        public static int Negamax(BoardState node, Point sim, UniqueMoveBoardMap map, Dictionary<int, TTEntry> tt, int depth, int alpha, int beta, int color)
        {

            int alphaOrig = alpha;
            //int stateCode = node.GetStateCode();
            //if (tt.TryGetValue(stateCode, out TTEntry ttEntry) && ttEntry.Depth >= depth)
            //{
            //    //Console.WriteLine(ttEntry);
            //    if (ttEntry.Flag == NodeState.EXACT) return ttEntry.Value;
            //    else if (ttEntry.Flag == NodeState.LOWERBOUND)
            //        alpha = Math.Max(alpha, ttEntry.Value);
            //    else beta = Math.Min(beta, ttEntry.Value); // UPPERBOUND


            //    if (alpha >= beta) return ttEntry.Value;
            //}

            count++;
            if (node.SearchFrom(sim, null, true)) return -100;
            if (depth == 0) return 0;
            List<Move> moves = map.GetAllMoves(node);
            int value = -100;
            for (int i = 0; i < moves.Count; i++)
            {
                sim = node.Alter(moves[i], true);
                value = Math.Max(value, -Negamax(node, sim, map, tt, depth - 1, -beta, -alpha, -color));
                node.Undo();

                alpha = Math.Max(alpha, value);
                if (alpha >= beta) break;
            }

            //ttEntry.Value = value;
            //if (value <= alphaOrig) ttEntry.Flag = NodeState.LOWERBOUND;
            //else if (value >= beta) ttEntry.Flag = NodeState.UPPERBOUND;
            //else ttEntry.Flag = NodeState.EXACT;
            //ttEntry.Depth = depth;

            //tt[stateCode] = ttEntry;

            return value;
        }

        public struct TTEntry
        {
            public NodeState Flag;
            public int Value;
            public int Depth;
            public TTEntry(NodeState flag, int value, int depth)
            {
                Flag = flag;
                Value = value;
                Depth = depth;
            }
            public override string ToString()
            {
                return $"Flag: {Flag}, Value: {Value}, Depth: {Depth}";
            }
        }

        public enum NodeState
        {
            EXACT,
            LOWERBOUND,
            UPPERBOUND,
        }
    }
}
